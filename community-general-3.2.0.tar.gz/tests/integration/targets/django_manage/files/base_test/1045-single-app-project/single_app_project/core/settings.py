# single_app_project/core/settings.py
SECRET_KEY = 'testtesttesttesttest'
